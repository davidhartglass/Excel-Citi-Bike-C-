﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace Davids_Project
{
    [DataContract]
    class Inventory
    {
        [DataMember]
        private string Soda { get; set; }

        [DataMember]
        private string SodaName { get; set; }
        
        [DataMember]
        private string color { get; set; }

        [DataMember]
        private int calories { get; set; }

        [DataMember]
        private string [] flavor { get; set; }


        public string GetMyJSON()
        {
            Inventory myInventory = new Inventory();
            myInventory.flavor = new string[2];

            myInventory.Soda = "Drink";
            myInventory.SodaName = "Coke";
            myInventory.color = "red";
            myInventory.calories = 180;
            myInventory.flavor[0] = "Cherry";
            myInventory.flavor[1] = "Vanilla";

            DataContractJsonSerializer mySerializer = new DataContractJsonSerializer(typeof(Inventory));
            using (MemoryStream stream = new MemoryStream())
            {
                mySerializer.WriteObject(stream, myInventory);

                using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(@"C:\Users\DGH\Desktop\ExcelFilenameCounter\Davids_Project\bin\Debug\inventory.txt", true))
                {
                    file.WriteLine(Encoding.Default.GetString(stream.ToArray()));
                }

                return Encoding.Default.GetString(stream.ToArray());
            }
        }
    }
}
