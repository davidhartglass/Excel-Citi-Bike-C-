﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Davids_Project
{
    /// <summary>
    /// Interaction logic for JSON_Window.xaml
    /// </summary>
    public partial class JSON_Window : Window
    {
        private List<SingleBike> myBikes;
        private CitiBikes myCitiBikes;
        private string executionTime;
        public JSON_Window()
        {
            InitializeComponent();
        }

        private void GoButton_Click(object sender, RoutedEventArgs e)
        {
            //Inventory inventory = new Inventory();
            //inventory.GetMyJSON();
            myCitiBikes = new CitiBikes();

            string json = myCitiBikes.getMyJSON();

            dynamic stuff = JObject.Parse(json);

            myBikes = stuff.stationBeanList.ToObject<List<SingleBike>>();
            executionTime = stuff.executionTime;


            updateListBox();
        }

        private void updateListBox()
        {
            if (listViewBikes.Items.Count > 0)
            {
                listViewBikes.Items.Clear();
            }

            for (int i = 0; i < myBikes.Count; i++)
            {
                listViewBikes.Items.Add(myBikes[i].ID);
            }

            listViewBikes.SelectedIndex = 0;
            updateLastDownloadLabel();
            listViewBikes.Items.Refresh();
        }

        private void listViewBikes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listViewBikes.SelectedIndex == -1)
            {
                listViewBikes.SelectedIndex = 0;
            }
            else
            {

                stationNametxt.Text = null;
                statusTxt.Text = null;
                lastContactTxt.Text = null;
                AvailableDockstxt.Text = null;
                totalDocksTxt.Text = null;
                latitudeTxt.Text = null;
                longitudeTxt.Text = null;

                stationNametxt.Text = myBikes[listViewBikes.SelectedIndex].stationName;
                statusTxt.Text = myBikes[listViewBikes.SelectedIndex].statusValue;
                lastContactTxt.Text = myBikes[listViewBikes.SelectedIndex].lastCommunicationTime;
                AvailableDockstxt.Text = myBikes[listViewBikes.SelectedIndex].availableDocks.ToString();
                totalDocksTxt.Text = myBikes[listViewBikes.SelectedIndex].totalDocks.ToString();
                latitudeTxt.Text = myBikes[listViewBikes.SelectedIndex].latitude.ToString();
                longitudeTxt.Text = myBikes[listViewBikes.SelectedIndex].longitude.ToString();


                if (myBikes[listViewBikes.SelectedIndex].statusValue == "In Service")
                {
                    statusIndicator.Fill = Brushes.Green;
                }
                else if (myBikes[listViewBikes.SelectedIndex].statusValue == "Not In Service")
                {
                    statusIndicator.Fill = Brushes.Red;
                }
                else
                {
                    statusIndicator.Fill = Brushes.Gray;
                }
             
            }
        }

        private void refreshButton_Click(object sender, RoutedEventArgs e)
        {
            myCitiBikes = new CitiBikes();

            string json = myCitiBikes.getMyJSON();

            updateLastDownloadLabel();
            updateListBox();
        }

        private void openExcelButton_Click(object sender, RoutedEventArgs e)
        {
            Window mainWindow = new MainWindow();
            mainWindow.Show();

            this.Close();
        }

        private void updateLastDownloadLabel()
        {
            LastDownloadDate.Content = "";
            LastDownloadDate.Content = "Last Download: " + executionTime;
        }
    }
}
