﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Runtime.Serialization;

namespace Davids_Project
{
    [DataContract]
    class CitiBikes
    {
        [DataMember]
        public  Dictionary<String, SingleBike[]> myDictionary;

        [DataMember]
        public string excecutionTime { get; set; }
        public List<SingleBike> stationBeanList { get; set; }

        public string getMyJSON()
        {

            using (WebClient wc = new WebClient())
            {
                var json = wc.DownloadString("https://feeds.citibikenyc.com/stations/stations.json");
                return json;
            }
        }
    }
}
