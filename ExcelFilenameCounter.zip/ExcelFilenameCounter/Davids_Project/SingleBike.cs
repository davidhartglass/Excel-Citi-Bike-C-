﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Davids_Project
{
    [DataContract]
    class SingleBike
    {
        [DataMember]
        public int ID { get; set; }
        [DataMember]
        public string stationName { get; set; }
        [DataMember]
        public int availableDocks { get; set; }
        [DataMember]
        public int totalDocks { get; set; }
        [DataMember]
        public double latitude { get; set; }
        [DataMember]
        public double longitude { get; set; }
        [DataMember]
        public string statusValue { get; set; }
        [DataMember]
        public string statusKey { get; set; }
        [DataMember]
        public int availableBikes { get; set; }
        [DataMember]
        public string stAddress1 { get; set; }
        [DataMember]
        public string stAddress2 { get; set; }
        [DataMember]
        public string city { get; set; }
        [DataMember]
        public string postalCode { get; set; }
        [DataMember]
        public string location { get; set; }
        [DataMember]
        public string altitude { get; set; }
        [DataMember]
        public bool testStation { get; set; }
        [DataMember]
        public string lastCommunicationTime { get; set; }
        [DataMember]
        public string landmark { get; set; }
    }
}
